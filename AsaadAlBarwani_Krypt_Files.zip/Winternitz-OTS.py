import hashlib,random,sys, binascii
hexdigest_size=16
a = 1*10**32
b = 9.99999999999999999999999999999999*10**32
x=random.randint(a,b)
print("Key X is:", x)

y=hashlib.sha512(bin(x).encode()).hexdigest()
y1 = hashlib.sha512(y.encode()).hexdigest()
y2 = hashlib.sha512(y1.encode()).hexdigest()

print ("Key Y is:", y2)

